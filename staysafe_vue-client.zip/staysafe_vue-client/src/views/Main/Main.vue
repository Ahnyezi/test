<template>
    <v-main>
        <SearchMain />
    </v-main>
</template>

<script>
import SearchMain from "@/components/SearchMain/SearchMain"
export default {
    components: {
        SearchMain
    },
    data: () => ({

    }),
};
</script>
